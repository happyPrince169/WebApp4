/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyServlets;

import com.connection.DatabaseAccess;
import com.entities.User;
import com.dao.UserDAO;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 *
 * @author Lenovo
 */
@WebServlet(name = "LoginProcess", urlPatterns = {"/LoginProcess"})
public class LoginProcess extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LoginProcess</title>");
            out.println("</head>");
            out.println("<body>");
            HttpSession session = request.getSession(false);
            String action = request.getParameter("action");
            UserDAO userDao = new UserDAO();
            User u = new User();
            if (session != null && session.getAttribute("username") != null) {
                //khi da log in thi se ko log in bang account khac duoc
                response.sendRedirect("index.jsp");
            } else {

                if ("Sign Up".equals(action)) {
                    String newUsername = request.getParameter("newUsername");
                    String newPassword = request.getParameter("newPassword");

                    if (userDao.searchUser(newUsername, newPassword)) {
                        RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.jsp");
                        out.println("<font color=red>This username is already taken.</font>");
                        rd.include(request, response);
                    } else {
                        u.setUsername(newUsername);
                        u.setPassword(newPassword);
                        userDao.save(u);
                        RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.jsp");
                        out.println("<font color=green>You have signed up successfully, now you are able to sign in.</font>");
                        rd.include(request, response);
                    }

                } else if ("Sign In".equals(action)) {
                    String username = request.getParameter("username");
                    String password = request.getParameter("password");
                    if (userDao.searchUser(username, password)) {
                        session = request.getSession(true);
                        session.setAttribute("username", username);
                        response.sendRedirect("index.jsp");
                    } else {
                        RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.jsp");
                        out.println("<font color=red>Either username or password is wrong.</font>");
                        rd.include(request, response);
                    }
                }
            }
            out.println("</body>");
            out.println("</html>");
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        session.invalidate();

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
