/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entities;

import java.sql.Timestamp;

/**
 *
 * @author Lenovo
 */
public class Post {

    private String title = "";
    private String username = "";
    private String content = "";
    private String brief = "";
    private String stat = "";
    private String category = "";
    private Timestamp time;
    private int postId = 0;
    
    public Post(){
    
    }
    
    public Post(int postId, String title, String username, String content, String brief, String stat, String category, Timestamp time){
     this.postId = postId;
     this.title = title;
     this.username = username;
     this.content = content;
     this.brief = brief;
     this.stat = stat;
     this.category = category;
     this.time = time;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getBrief() {
        return brief;
    }

    public void setBrief(String brief) {
        this.brief = brief;
    }

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }

    public int getPostId() {
        return postId;
    }

    public void setPostId(int postId) {
        this.postId = postId;
    }
    
    

}
