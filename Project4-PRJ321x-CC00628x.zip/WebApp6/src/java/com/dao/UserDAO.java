/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.connection.DatabaseAccess;
import com.entities.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Lenovo
 */
public class UserDAO implements UserInterface {

    User u = new User();

    @Override
    public void save(User u) {
        
        PreparedStatement insertUser = null;
        
        String insertString = "INSERT INTO myblog.users (UserName, Password ) VALUES (?, ?)";
        
        try {
            Connection conn = DatabaseAccess.getConnection();
            insertUser = conn.prepareStatement(insertString);
            
            insertUser.setString(1, u.getUsername());
            insertUser.setString(2, u.getPassword());
            insertUser.executeUpdate();
            
            
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean searchUser(String username, String password) {
        boolean f = true;
        PreparedStatement selectUser = null;
        String selectString = "SELECT UserName, Password from myblog.users where UserName=? and Password=?";

        try {
            Connection conn = DatabaseAccess.getConnection();
            selectUser = conn.prepareStatement(selectString);
            selectUser.setString(1, username);
            selectUser.setString(2, password);
            ResultSet r = selectUser.executeQuery();
            if (r.next()) {
                f = true;
            } else {
                f = false;
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        return f;
    }

}
