/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.connection.DatabaseAccess;
import com.entities.Post;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class PostDAO implements PostInterface {

    private Post p = new Post();
    private List<Post> listPost = new ArrayList();
    private Connection conn;

    @Override
    public int savePost(Post p) {
        int id = 0;
        PreparedStatement insertPost = null;
        String insertString = "INSERT INTO myblog.posts (UserName, Title, Content, Brief, Stat, Category, Time) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            conn = DatabaseAccess.getConnection();
            insertPost = conn.prepareStatement(insertString);
            insertPost.setString(1, p.getUsername());
            insertPost.setString(2, p.getTitle());
            insertPost.setString(3, p.getContent());
            insertPost.setString(4, p.getBrief());
            insertPost.setString(5, p.getStat());
            insertPost.setString(6, p.getCategory());
            insertPost.setTimestamp(7, p.getTime());
            insertPost.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return id;
    }

    public int countPost(String stat) {
        int i = 0;
        PreparedStatement count = null;
        String sql = "select count(*) from posts WHERE stat = ?";
        try {
            conn = DatabaseAccess.getConnection();
            count = conn.prepareStatement(sql);
            count.setString(1, stat);
            ResultSet r = count.executeQuery();
            if (r.next()) {
                i = r.getInt(1);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return i;
    }

    public int getLastId() {
        int id = 0;
        PreparedStatement getLastId = null;
        String getIdString = "SELECT PostID FROM posts ORDER BY PostID DESC LIMIT 1";
        try {
            conn = DatabaseAccess.getConnection();
            getLastId = conn.prepareStatement(getIdString);
            ResultSet r = getLastId.executeQuery();
            if (r.next()) {
                id = r.getInt("PostID");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        return id;
    }

    @Override
    public Post getPostById(int postId) {
        PreparedStatement selectPost = null;
        ResultSet r = null;

        String selectString = "SELECT * from posts where PostID = ?";
        try {
            conn = DatabaseAccess.getConnection();
            selectPost = conn.prepareStatement(selectString);
            selectPost.setInt(1, postId);
            r = selectPost.executeQuery();
            if (r.next()) {
                p.setPostId(postId);
                p.setUsername(r.getString("UserName"));
                p.setTitle(r.getString("Title"));
                p.setContent(r.getString("Content"));
                p.setBrief(r.getString("Brief"));
                p.setStat(r.getString("Stat"));
                p.setCategory(r.getString("Category"));
                p.setTime(r.getTimestamp("Time"));
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        return p;
    }

    @Override
    public void updatePost(Post p) {
        PreparedStatement editPost = null;
        String selectString = "UPDATE posts set Title=?, Content=?, Brief=?, Stat=?, Category=? where PostID = ?";
        try {
            conn = DatabaseAccess.getConnection();
            editPost = conn.prepareStatement(selectString);
            editPost.setString(1, p.getTitle());
            editPost.setString(2, p.getContent());
            editPost.setString(3, p.getBrief());
            editPost.setString(4, p.getStat());
            editPost.setString(5, p.getCategory());
            editPost.setInt(6, p.getPostId());
            editPost.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Post> getAllPosts(String sql, String stat, int i) {
        PreparedStatement selectPost = null;
        String selectString = "SELECT * FROM posts WHERE stat = ? " + sql + " ORDER BY PostID DESC LIMIT ? ;";//SELECT * FROM posts ORDER BY PostID DESC LIMIT 5;
        ResultSet r = null;

        List<Post> listPost = new ArrayList();
        try {
            conn = DatabaseAccess.getConnection();
            selectPost = conn.prepareStatement(selectString);
            selectPost.setString(1, stat);
            selectPost.setInt(2, i);
            r = selectPost.executeQuery();
            while (r.next()) {

                Post p = new Post();
                p.setPostId(r.getInt("PostID"));
                p.setUsername(r.getString("UserName"));
                p.setTitle(r.getString("Title"));
                p.setContent(r.getString("Content"));
                p.setBrief(r.getString("Brief"));
                p.setStat(r.getString("Stat"));
                p.setCategory(r.getString("Category"));
                p.setTime(r.getTimestamp("Time"));

                listPost.add(p);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return listPost;
    }

    public List<Post> getAllPostsByUser(String username, String stat) {
        PreparedStatement selectPost = null;
        String selectString = "SELECT * FROM posts WHERE UserName = ? AND Stat = ? ORDER BY PostID DESC";//SELECT * FROM posts ORDER BY PostID DESC LIMIT 5;
        ResultSet r = null;

        List<Post> listPost = new ArrayList();
        try {
            conn = DatabaseAccess.getConnection();
            selectPost = conn.prepareStatement(selectString);
            selectPost.setString(1, username);
            selectPost.setString(2, stat);
            r = selectPost.executeQuery();
            while (r.next()) {

                Post p = new Post();
                p.setPostId(r.getInt("PostID"));
                p.setUsername(r.getString("UserName"));
                p.setTitle(r.getString("Title"));
                p.setContent(r.getString("Content"));
                p.setBrief(r.getString("Brief"));
                p.setStat(r.getString("Stat"));
                p.setCategory(r.getString("Category"));
                p.setTime(r.getTimestamp("Time"));

                listPost.add(p);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return listPost;
    }

    @Override
    public void deletePost(int id) {
        PreparedStatement delPost = null;
        String selectString = "DELETE from posts where PostID = ?";
        try {
            conn = DatabaseAccess.getConnection();
            delPost = conn.prepareStatement(selectString);
            delPost.setInt(1, id);
            delPost.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

}
