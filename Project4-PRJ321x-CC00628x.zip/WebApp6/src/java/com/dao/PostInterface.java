/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.entities.Post;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public interface PostInterface {
    public int savePost(Post p);
    public void updatePost(Post p);
    public Post getPostById(int id);
    public List<Post> getAllPosts(String sql, String stat, int i);   
    public void deletePost(int id);
}
